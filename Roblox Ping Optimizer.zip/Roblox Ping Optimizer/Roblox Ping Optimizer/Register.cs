﻿using System.Diagnostics;
using System.Runtime.InteropServices;

namespace Roblox_Ping_Optimizer
{
    public partial class Register : Form
    {
        public Register()
        {
            InitializeComponent();
        }
        [DllImport("user32.DLL", EntryPoint = "ReleaseCapture")]
        private extern static void ReleaseCapture();
        [DllImport("user32.DLL", EntryPoint = "SendMessage")]
        private extern static void SendMessage(System.IntPtr one, int two, int three, int four);
        private void border_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(Handle, 0x112, 0xf012, 0);
        }

        private void register_buttn_Click(object sender, EventArgs e)
        {
            Register_Handle handle = new Register_Handle();
            Main main = new Main();

            if (handle.register_user(input_key: textBox2.Text))
            {
                this.Hide();
                main.ShowDialog();
            }
        }

        private void close_btn_Click_1(object sender, EventArgs e)
        {
            DialogResult user_ask = MessageBox.Show(
                "Are you sure you want to close the application?",
                "Proceed",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);

            if (user_ask == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void get_key_Click(object sender, EventArgs e)
        {
            string shortLink = "https://bit.ly/4hVOwKb";  // Example short link

            MessageBox.Show(
                $"To retrieve your key, please click 'OK' to open the following link in your browser: \n\n{shortLink}\n\nIf the link doesn't open, copy and paste it manually into your browser.",
                "Retrieve Your Key",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information
            );

            try
            {
                Process.Start("explorer", shortLink);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void link_Click(object sender, EventArgs e)
        {
            string link = "https://bit.ly/4hVOwKb";

            Clipboard.SetText(link);
            MessageBox.Show("Link copied successfully. Paste it into your browser.", "Copy", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            try
            {
                string? help_file = ".//Optimizer.chm";

                Help.ShowHelp(this, help_file);
            }

            catch (FileNotFoundException)
            {
                MessageBox.Show("The help file could not be found. Please ensure the file is in the correct location.",
                                "Help File Missing",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Warning);
            }
        }
    }
}
