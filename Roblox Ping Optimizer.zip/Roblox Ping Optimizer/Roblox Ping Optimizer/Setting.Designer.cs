﻿namespace Roblox_Ping_Optimizer
{
    partial class Setting
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Setting));
            label1 = new Label();
            panel1 = new Panel();
            default_roblox = new RadioButton();
            high_fast = new RadioButton();
            ultra_fast = new RadioButton();
            label4 = new Label();
            panel2 = new Panel();
            default_background = new RadioButton();
            enable_background = new RadioButton();
            disable_bakcground = new RadioButton();
            panel3 = new Panel();
            default_graphic = new RadioButton();
            auto_graphic = new RadioButton();
            ultra_graphic = new RadioButton();
            label5 = new Label();
            panel4 = new Panel();
            default_wallpaper = new RadioButton();
            enable_wallpaper = new RadioButton();
            disable_wallpaper = new RadioButton();
            label6 = new Label();
            panel5 = new Panel();
            startup_default = new RadioButton();
            startup_enable = new RadioButton();
            startup_disable = new RadioButton();
            label7 = new Label();
            Save = new Button();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            panel3.SuspendLayout();
            panel4.SuspendLayout();
            panel5.SuspendLayout();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Microsoft Sans Serif", 12F);
            label1.Location = new Point(12, 53);
            label1.Name = "label1";
            label1.Size = new Size(113, 20);
            label1.TabIndex = 0;
            label1.Text = "Roblox Setting";
            // 
            // panel1
            // 
            panel1.BackColor = Color.Transparent;
            panel1.BackgroundImageLayout = ImageLayout.None;
            panel1.Controls.Add(default_roblox);
            panel1.Controls.Add(high_fast);
            panel1.Controls.Add(ultra_fast);
            panel1.Location = new Point(12, 76);
            panel1.Name = "panel1";
            panel1.Size = new Size(332, 29);
            panel1.TabIndex = 4;
            // 
            // default_roblox
            // 
            default_roblox.AutoSize = true;
            default_roblox.BackColor = Color.Transparent;
            default_roblox.Location = new Point(260, 5);
            default_roblox.Name = "default_roblox";
            default_roblox.Size = new Size(63, 19);
            default_roblox.TabIndex = 6;
            default_roblox.TabStop = true;
            default_roblox.Text = "Default";
            default_roblox.UseVisualStyleBackColor = false;
            // 
            // high_fast
            // 
            high_fast.AutoSize = true;
            high_fast.BackColor = Color.Transparent;
            high_fast.Location = new Point(140, 5);
            high_fast.Name = "high_fast";
            high_fast.Size = new Size(75, 19);
            high_fast.TabIndex = 5;
            high_fast.TabStop = true;
            high_fast.Text = "High Fast";
            high_fast.UseVisualStyleBackColor = false;
            // 
            // ultra_fast
            // 
            ultra_fast.AutoSize = true;
            ultra_fast.BackColor = Color.Transparent;
            ultra_fast.Location = new Point(9, 5);
            ultra_fast.Name = "ultra_fast";
            ultra_fast.Size = new Size(76, 19);
            ultra_fast.TabIndex = 4;
            ultra_fast.TabStop = true;
            ultra_fast.Text = "Ultra_Fast";
            ultra_fast.UseVisualStyleBackColor = false;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = Color.Transparent;
            label4.Font = new Font("Microsoft Sans Serif", 12F);
            label4.Location = new Point(12, 108);
            label4.Name = "label4";
            label4.Size = new Size(136, 20);
            label4.TabIndex = 12;
            label4.Text = "Background Apps";
            // 
            // panel2
            // 
            panel2.BackColor = Color.Transparent;
            panel2.BackgroundImageLayout = ImageLayout.None;
            panel2.Controls.Add(default_background);
            panel2.Controls.Add(enable_background);
            panel2.Controls.Add(disable_bakcground);
            panel2.Location = new Point(12, 131);
            panel2.Name = "panel2";
            panel2.Size = new Size(332, 29);
            panel2.TabIndex = 7;
            // 
            // default_background
            // 
            default_background.AutoSize = true;
            default_background.BackColor = Color.Transparent;
            default_background.Location = new Point(260, 5);
            default_background.Name = "default_background";
            default_background.Size = new Size(63, 19);
            default_background.TabIndex = 6;
            default_background.TabStop = true;
            default_background.Text = "Default";
            default_background.UseVisualStyleBackColor = false;
            // 
            // enable_background
            // 
            enable_background.AutoSize = true;
            enable_background.BackColor = Color.Transparent;
            enable_background.Location = new Point(140, 5);
            enable_background.Name = "enable_background";
            enable_background.Size = new Size(77, 19);
            enable_background.TabIndex = 5;
            enable_background.TabStop = true;
            enable_background.Text = "Enable All";
            enable_background.UseVisualStyleBackColor = false;
            // 
            // disable_bakcground
            // 
            disable_bakcground.AutoSize = true;
            disable_bakcground.BackColor = Color.Transparent;
            disable_bakcground.Location = new Point(9, 5);
            disable_bakcground.Name = "disable_bakcground";
            disable_bakcground.Size = new Size(80, 19);
            disable_bakcground.TabIndex = 4;
            disable_bakcground.TabStop = true;
            disable_bakcground.Text = "Disable All";
            disable_bakcground.UseVisualStyleBackColor = false;
            // 
            // panel3
            // 
            panel3.BackColor = Color.Transparent;
            panel3.BackgroundImageLayout = ImageLayout.None;
            panel3.Controls.Add(default_graphic);
            panel3.Controls.Add(auto_graphic);
            panel3.Controls.Add(ultra_graphic);
            panel3.Location = new Point(12, 196);
            panel3.Name = "panel3";
            panel3.Size = new Size(332, 29);
            panel3.TabIndex = 13;
            // 
            // default_graphic
            // 
            default_graphic.AutoSize = true;
            default_graphic.BackColor = Color.Transparent;
            default_graphic.Location = new Point(260, 3);
            default_graphic.Name = "default_graphic";
            default_graphic.Size = new Size(63, 19);
            default_graphic.TabIndex = 6;
            default_graphic.TabStop = true;
            default_graphic.Text = "Default";
            default_graphic.UseVisualStyleBackColor = false;
            // 
            // auto_graphic
            // 
            auto_graphic.AutoSize = true;
            auto_graphic.BackColor = Color.Transparent;
            auto_graphic.Location = new Point(140, 3);
            auto_graphic.Name = "auto_graphic";
            auto_graphic.Size = new Size(88, 19);
            auto_graphic.TabIndex = 5;
            auto_graphic.TabStop = true;
            auto_graphic.Text = "Auto Detect";
            auto_graphic.UseVisualStyleBackColor = false;
            // 
            // ultra_graphic
            // 
            ultra_graphic.AutoSize = true;
            ultra_graphic.BackColor = Color.Transparent;
            ultra_graphic.Location = new Point(9, 5);
            ultra_graphic.Name = "ultra_graphic";
            ultra_graphic.Size = new Size(74, 19);
            ultra_graphic.TabIndex = 4;
            ultra_graphic.TabStop = true;
            ultra_graphic.Text = "Ultra Fast";
            ultra_graphic.UseVisualStyleBackColor = false;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.BackColor = Color.Transparent;
            label5.Font = new Font("Microsoft Sans Serif", 12F);
            label5.Location = new Point(12, 173);
            label5.Name = "label5";
            label5.Size = new Size(131, 20);
            label5.TabIndex = 14;
            label5.Text = "Graphic Optimize";
            // 
            // panel4
            // 
            panel4.BackColor = Color.Transparent;
            panel4.BackgroundImageLayout = ImageLayout.None;
            panel4.Controls.Add(default_wallpaper);
            panel4.Controls.Add(enable_wallpaper);
            panel4.Controls.Add(disable_wallpaper);
            panel4.Location = new Point(12, 261);
            panel4.Name = "panel4";
            panel4.Size = new Size(332, 29);
            panel4.TabIndex = 15;
            // 
            // default_wallpaper
            // 
            default_wallpaper.AutoSize = true;
            default_wallpaper.BackColor = Color.Transparent;
            default_wallpaper.Location = new Point(260, 7);
            default_wallpaper.Name = "default_wallpaper";
            default_wallpaper.Size = new Size(63, 19);
            default_wallpaper.TabIndex = 6;
            default_wallpaper.TabStop = true;
            default_wallpaper.Text = "Default";
            default_wallpaper.UseVisualStyleBackColor = false;
            // 
            // enable_wallpaper
            // 
            enable_wallpaper.AutoSize = true;
            enable_wallpaper.BackColor = Color.Transparent;
            enable_wallpaper.Location = new Point(140, 5);
            enable_wallpaper.Name = "enable_wallpaper";
            enable_wallpaper.Size = new Size(60, 19);
            enable_wallpaper.TabIndex = 5;
            enable_wallpaper.TabStop = true;
            enable_wallpaper.Text = "Enable";
            enable_wallpaper.UseVisualStyleBackColor = false;
            // 
            // disable_wallpaper
            // 
            disable_wallpaper.AutoSize = true;
            disable_wallpaper.BackColor = Color.Transparent;
            disable_wallpaper.Location = new Point(9, 5);
            disable_wallpaper.Name = "disable_wallpaper";
            disable_wallpaper.Size = new Size(63, 19);
            disable_wallpaper.TabIndex = 4;
            disable_wallpaper.TabStop = true;
            disable_wallpaper.Text = "Disable";
            disable_wallpaper.UseVisualStyleBackColor = false;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.BackColor = Color.Transparent;
            label6.Font = new Font("Microsoft Sans Serif", 12F);
            label6.Location = new Point(12, 238);
            label6.Name = "label6";
            label6.Size = new Size(144, 20);
            label6.TabIndex = 16;
            label6.Text = "Desktop Wallpaper";
            // 
            // panel5
            // 
            panel5.BackColor = Color.Transparent;
            panel5.BackgroundImageLayout = ImageLayout.None;
            panel5.Controls.Add(startup_default);
            panel5.Controls.Add(startup_enable);
            panel5.Controls.Add(startup_disable);
            panel5.Location = new Point(12, 325);
            panel5.Name = "panel5";
            panel5.Size = new Size(332, 29);
            panel5.TabIndex = 17;
            // 
            // startup_default
            // 
            startup_default.AutoSize = true;
            startup_default.BackColor = Color.Transparent;
            startup_default.Location = new Point(260, 5);
            startup_default.Name = "startup_default";
            startup_default.Size = new Size(63, 19);
            startup_default.TabIndex = 6;
            startup_default.TabStop = true;
            startup_default.Text = "Default";
            startup_default.UseVisualStyleBackColor = false;
            // 
            // startup_enable
            // 
            startup_enable.AutoSize = true;
            startup_enable.BackColor = Color.Transparent;
            startup_enable.Location = new Point(140, 5);
            startup_enable.Name = "startup_enable";
            startup_enable.Size = new Size(77, 19);
            startup_enable.TabIndex = 5;
            startup_enable.TabStop = true;
            startup_enable.Text = "Enable All";
            startup_enable.UseVisualStyleBackColor = false;
            // 
            // startup_disable
            // 
            startup_disable.AutoSize = true;
            startup_disable.BackColor = Color.Transparent;
            startup_disable.Location = new Point(9, 5);
            startup_disable.Name = "startup_disable";
            startup_disable.Size = new Size(80, 19);
            startup_disable.TabIndex = 4;
            startup_disable.TabStop = true;
            startup_disable.Text = "Disable All";
            startup_disable.UseVisualStyleBackColor = false;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.BackColor = Color.Transparent;
            label7.Font = new Font("Microsoft Sans Serif", 12F);
            label7.Location = new Point(12, 302);
            label7.Name = "label7";
            label7.Size = new Size(103, 20);
            label7.TabIndex = 18;
            label7.Text = "Startup Apps";
            // 
            // Save
            // 
            Save.BackColor = Color.FromArgb(161, 209, 229);
            Save.BackgroundImageLayout = ImageLayout.None;
            Save.Cursor = Cursors.Hand;
            Save.FlatAppearance.BorderSize = 0;
            Save.FlatStyle = FlatStyle.Flat;
            Save.Font = new Font("Microsoft Sans Serif", 11.25F);
            Save.Location = new Point(97, 363);
            Save.Name = "Save";
            Save.Size = new Size(132, 39);
            Save.TabIndex = 19;
            Save.Text = "Save";
            Save.UseVisualStyleBackColor = false;
            Save.Click += Save_Click;
            // 
            // Setting
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.None;
            ClientSize = new Size(353, 414);
            Controls.Add(Save);
            Controls.Add(panel5);
            Controls.Add(label7);
            Controls.Add(panel4);
            Controls.Add(label6);
            Controls.Add(panel3);
            Controls.Add(label5);
            Controls.Add(panel2);
            Controls.Add(label4);
            Controls.Add(panel1);
            Controls.Add(label1);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "Setting";
            Text = "Setting";
            Load += Setting_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            panel3.ResumeLayout(false);
            panel3.PerformLayout();
            panel4.ResumeLayout(false);
            panel4.PerformLayout();
            panel5.ResumeLayout(false);
            panel5.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Panel panel1;
        private RadioButton default_roblox;
        private RadioButton high_fast;
        private RadioButton ultra_fast;
        private Label label4;
        private Panel panel2;
        private RadioButton default_background;
        private RadioButton enable_background;
        private RadioButton disable_bakcground;
        private Panel panel3;
        private RadioButton default_graphic;
        private RadioButton auto_graphic;
        private RadioButton ultra_graphic;
        private Label label5;
        private Panel panel4;
        private RadioButton default_wallpaper;
        private RadioButton enable_wallpaper;
        private RadioButton disable_wallpaper;
        private Label label6;
        private Panel panel5;
        private RadioButton startup_default;
        private RadioButton startup_enable;
        private RadioButton startup_disable;
        private Label label7;
        private Button Save;
    }
}