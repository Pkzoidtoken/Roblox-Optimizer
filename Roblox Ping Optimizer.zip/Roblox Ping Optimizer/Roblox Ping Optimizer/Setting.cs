﻿using Microsoft.Win32;

namespace Roblox_Ping_Optimizer
{
    public partial class Setting : Form
    {
        public Setting()
        {
            InitializeComponent();
        }

        private void Setting_Load(object sender, EventArgs e)
        {
            using (RegistryKey? key = Registry.CurrentUser.OpenSubKey("SOFTWARE\\roblox_ping_optimizer", writable: false))

            {
                if (key != null)
                {
                    ultra_fast.Checked = Convert.ToBoolean(key.GetValue("ultra_fast"));
                    high_fast.Checked = Convert.ToBoolean(key.GetValue("high_fast"));
                    default_roblox.Checked = Convert.ToBoolean(key.GetValue("default_roblox"));

                    disable_bakcground.Checked = Convert.ToBoolean(key.GetValue("disable_background"));
                    enable_background.Checked = Convert.ToBoolean(key.GetValue("enable_background"));
                    default_background.Checked = Convert.ToBoolean(key.GetValue("default_background"));

                    ultra_graphic.Checked = Convert.ToBoolean(key.GetValue("ultra_graphic"));
                    auto_graphic.Checked = Convert.ToBoolean(key.GetValue("high_graphic"));
                    default_graphic.Checked = Convert.ToBoolean(key.GetValue("default_graphic"));

                    disable_wallpaper.Checked = Convert.ToBoolean(key.GetValue("disable_wallpaper"));
                    enable_wallpaper.Checked = Convert.ToBoolean(key.GetValue("enable_wallpaper"));
                    default_wallpaper.Checked = Convert.ToBoolean(key.GetValue("default_wallpaper"));

                    startup_disable.Checked = Convert.ToBoolean(key.GetValue("disable_startup"));
                    startup_enable.Checked = Convert.ToBoolean(key.GetValue("enable_startup"));
                    startup_default.Checked = Convert.ToBoolean(key.GetValue("default_startup"));
                }
                else
                {
                    ultra_fast.Checked = true;
                    disable_bakcground.Checked = true;
                    ultra_graphic.Checked = true;
                    disable_wallpaper.Checked = true;
                    startup_disable.Checked = true;
                }
            }

        }

        private void Save_Click(object sender, EventArgs e)
        {
            DialogResult user_ask = MessageBox.Show(
                "Do you want to save your settings?",
                "Proceed",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question
                );

            setting_handle handle = new setting_handle();

            if (user_ask == DialogResult.Yes)

            {
                handle.save_setting("default_roblox", default_roblox.Checked);
                handle.save_setting("high_fast", high_fast.Checked);
                handle.save_setting("ultra_fast", ultra_fast.Checked);

                handle.save_setting("disable_background", disable_bakcground.Checked);
                handle.save_setting("enable_background", enable_background.Checked);
                handle.save_setting("default_background", default_background.Checked);

                handle.save_setting("enable_wallpaper", enable_wallpaper.Checked);
                handle.save_setting("disable_wallpaper", disable_wallpaper.Checked);
                handle.save_setting("default_wallpaper", default_wallpaper.Checked);

                handle.save_setting("ultra_graphic", ultra_graphic.Checked);
                handle.save_setting("high_graphic", auto_graphic.Checked);
                handle.save_setting("default_graphic", default_graphic.Checked);

                handle.save_setting("enable_startup", startup_enable.Checked);
                handle.save_setting("disable_startup", startup_disable.Checked);
                handle.save_setting("default_startup", startup_default.Checked);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
        }
    }
}
