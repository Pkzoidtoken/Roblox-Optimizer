﻿namespace Roblox_Ping_Optimizer
{
    partial class Register
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Register));
            register_buttn = new Button();
            get_key = new Button();
            textBox2 = new TextBox();
            key_info = new Label();
            info_form = new Label();
            border = new Panel();
            pictureBox3 = new PictureBox();
            close_btn = new PictureBox();
            label1 = new Label();
            link = new Label();
            border.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)close_btn).BeginInit();
            SuspendLayout();
            // 
            // register_buttn
            // 
            register_buttn.BackColor = Color.FromArgb(161, 209, 229);
            register_buttn.BackgroundImageLayout = ImageLayout.None;
            register_buttn.Cursor = Cursors.Hand;
            register_buttn.FlatAppearance.BorderSize = 0;
            register_buttn.FlatStyle = FlatStyle.Flat;
            register_buttn.Font = new Font("Microsoft Sans Serif", 11.25F);
            register_buttn.Location = new Point(331, 127);
            register_buttn.Name = "register_buttn";
            register_buttn.Size = new Size(132, 39);
            register_buttn.TabIndex = 16;
            register_buttn.Text = "Register";
            register_buttn.UseVisualStyleBackColor = false;
            register_buttn.Click += register_buttn_Click;
            // 
            // get_key
            // 
            get_key.BackColor = Color.FromArgb(161, 209, 229);
            get_key.BackgroundImageLayout = ImageLayout.None;
            get_key.Cursor = Cursors.Hand;
            get_key.FlatAppearance.BorderSize = 0;
            get_key.FlatStyle = FlatStyle.Flat;
            get_key.Font = new Font("Microsoft Sans Serif", 11.25F);
            get_key.Location = new Point(193, 127);
            get_key.Name = "get_key";
            get_key.Size = new Size(132, 39);
            get_key.TabIndex = 15;
            get_key.Text = "Get Key";
            get_key.UseVisualStyleBackColor = false;
            get_key.Click += get_key_Click;
            // 
            // textBox2
            // 
            textBox2.Location = new Point(109, 88);
            textBox2.Multiline = true;
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(487, 23);
            textBox2.TabIndex = 14;
            // 
            // key_info
            // 
            key_info.AutoSize = true;
            key_info.BackColor = Color.Transparent;
            key_info.Font = new Font("Arial", 12.75F);
            key_info.Location = new Point(65, 88);
            key_info.Name = "key_info";
            key_info.Size = new Size(38, 19);
            key_info.TabIndex = 13;
            key_info.Text = "Key";
            // 
            // info_form
            // 
            info_form.AutoSize = true;
            info_form.BackColor = Color.Transparent;
            info_form.Font = new Font("Arial", 12.75F);
            info_form.Location = new Point(74, 57);
            info_form.Name = "info_form";
            info_form.Size = new Size(522, 19);
            info_form.TabIndex = 12;
            info_form.Text = "Enter the Registration Key you received after completing the short link.";
            // 
            // border
            // 
            border.BackColor = Color.Transparent;
            border.BackgroundImageLayout = ImageLayout.None;
            border.Controls.Add(pictureBox3);
            border.Controls.Add(close_btn);
            border.Location = new Point(3, 1);
            border.Name = "border";
            border.Size = new Size(634, 44);
            border.TabIndex = 11;
            border.MouseDown += border_MouseDown;
            // 
            // pictureBox3
            // 
            pictureBox3.Cursor = Cursors.Hand;
            pictureBox3.Image = (Image)resources.GetObject("pictureBox3.Image");
            pictureBox3.Location = new Point(584, 11);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(20, 20);
            pictureBox3.SizeMode = PictureBoxSizeMode.AutoSize;
            pictureBox3.TabIndex = 4;
            pictureBox3.TabStop = false;
            pictureBox3.Click += pictureBox3_Click;
            // 
            // close_btn
            // 
            close_btn.Cursor = Cursors.Hand;
            close_btn.Image = (Image)resources.GetObject("close_btn.Image");
            close_btn.Location = new Point(610, 11);
            close_btn.Name = "close_btn";
            close_btn.Size = new Size(18, 19);
            close_btn.TabIndex = 3;
            close_btn.TabStop = false;
            close_btn.Click += close_btn_Click_1;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Arial", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.Location = new Point(60, 179);
            label1.Name = "label1";
            label1.Size = new Size(405, 16);
            label1.TabIndex = 17;
            label1.Text = "The browser is not working. Copy and paste the link into your browse";
            // 
            // link
            // 
            link.AccessibleDescription = "";
            link.AutoSize = true;
            link.BackColor = Color.Transparent;
            link.Cursor = Cursors.Hand;
            link.FlatStyle = FlatStyle.Flat;
            link.Font = new Font("Arial", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            link.ForeColor = Color.Red;
            link.Location = new Point(469, 179);
            link.Name = "link";
            link.Size = new Size(138, 16);
            link.TabIndex = 18;
            link.Text = "https://bit.ly/4hVOwKb";
            link.TextAlign = ContentAlignment.MiddleCenter;
            link.Click += link_Click;
            // 
            // Register
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.None;
            ClientSize = new Size(640, 204);
            Controls.Add(link);
            Controls.Add(label1);
            Controls.Add(register_buttn);
            Controls.Add(get_key);
            Controls.Add(textBox2);
            Controls.Add(key_info);
            Controls.Add(info_form);
            Controls.Add(border);
            FormBorderStyle = FormBorderStyle.None;
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "Register";
            Text = "Register";
            border.ResumeLayout(false);
            border.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)close_btn).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button register_buttn;
        private Button get_key;
        private TextBox textBox2;
        private Label key_info;
        private Label info_form;
        private Panel border;
        private PictureBox pictureBox3;
        private PictureBox close_btn;
        private Label label1;
        private Label link;
    }
}