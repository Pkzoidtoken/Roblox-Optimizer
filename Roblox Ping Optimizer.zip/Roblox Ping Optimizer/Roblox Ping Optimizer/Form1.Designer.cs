﻿namespace Roblox_Ping_Optimizer
{
    partial class Main
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Main));
            pictureBox1 = new PictureBox();
            border = new Panel();
            setting_btn = new PictureBox();
            pictureBox3 = new PictureBox();
            close_btn = new PictureBox();
            graphic_pannel = new Panel();
            roblox_pannel = new Panel();
            internet_pannel = new Panel();
            wallpaper_pannel = new Panel();
            background_pannel = new Panel();
            startup_pannel = new Panel();
            Optmize = new Button();
            button1 = new Button();
            label1 = new Label();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            border.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)setting_btn).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)close_btn).BeginInit();
            SuspendLayout();
            // 
            // pictureBox1
            // 
            pictureBox1.Location = new Point(756, 12);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(20, 27);
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // border
            // 
            border.BackColor = Color.Transparent;
            border.BackgroundImageLayout = ImageLayout.None;
            border.Controls.Add(setting_btn);
            border.Controls.Add(pictureBox3);
            border.Controls.Add(close_btn);
            border.Location = new Point(0, 0);
            border.Name = "border";
            border.Size = new Size(791, 46);
            border.TabIndex = 1;
            border.MouseDown += border_MouseDown;
            // 
            // setting_btn
            // 
            setting_btn.Cursor = Cursors.Hand;
            setting_btn.Image = (Image)resources.GetObject("setting_btn.Image");
            setting_btn.Location = new Point(639, 12);
            setting_btn.Name = "setting_btn";
            setting_btn.Size = new Size(20, 20);
            setting_btn.SizeMode = PictureBoxSizeMode.AutoSize;
            setting_btn.TabIndex = 2;
            setting_btn.TabStop = false;
            setting_btn.Click += setting_btn_Click;
            // 
            // pictureBox3
            // 
            pictureBox3.Cursor = Cursors.Hand;
            pictureBox3.Image = (Image)resources.GetObject("pictureBox3.Image");
            pictureBox3.Location = new Point(665, 11);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(20, 20);
            pictureBox3.SizeMode = PictureBoxSizeMode.AutoSize;
            pictureBox3.TabIndex = 1;
            pictureBox3.TabStop = false;
            pictureBox3.Click += pictureBox3_Click;
            // 
            // close_btn
            // 
            close_btn.BackgroundImageLayout = ImageLayout.None;
            close_btn.Cursor = Cursors.Hand;
            close_btn.Image = (Image)resources.GetObject("close_btn.Image");
            close_btn.Location = new Point(691, 12);
            close_btn.Name = "close_btn";
            close_btn.Size = new Size(18, 19);
            close_btn.TabIndex = 0;
            close_btn.TabStop = false;
            close_btn.Click += close_btn_Click;
            // 
            // graphic_pannel
            // 
            graphic_pannel.BackColor = SystemColors.Control;
            graphic_pannel.BackgroundImage = (Image)resources.GetObject("graphic_pannel.BackgroundImage");
            graphic_pannel.BackgroundImageLayout = ImageLayout.None;
            graphic_pannel.Cursor = Cursors.Hand;
            graphic_pannel.Location = new Point(86, 94);
            graphic_pannel.Name = "graphic_pannel";
            graphic_pannel.Size = new Size(158, 148);
            graphic_pannel.TabIndex = 2;
            graphic_pannel.Click += graphic_pannel_Click;
            // 
            // roblox_pannel
            // 
            roblox_pannel.BackgroundImage = (Image)resources.GetObject("roblox_pannel.BackgroundImage");
            roblox_pannel.BackgroundImageLayout = ImageLayout.None;
            roblox_pannel.Cursor = Cursors.Hand;
            roblox_pannel.Location = new Point(289, 94);
            roblox_pannel.Name = "roblox_pannel";
            roblox_pannel.Size = new Size(158, 148);
            roblox_pannel.TabIndex = 3;
            roblox_pannel.Click += roblox_pannel_Click;
            // 
            // internet_pannel
            // 
            internet_pannel.BackgroundImage = (Image)resources.GetObject("internet_pannel.BackgroundImage");
            internet_pannel.Cursor = Cursors.Hand;
            internet_pannel.Location = new Point(495, 94);
            internet_pannel.Name = "internet_pannel";
            internet_pannel.Size = new Size(158, 148);
            internet_pannel.TabIndex = 4;
            internet_pannel.Click += internet_pannel_Click;
            // 
            // wallpaper_pannel
            // 
            wallpaper_pannel.BackgroundImage = (Image)resources.GetObject("wallpaper_pannel.BackgroundImage");
            wallpaper_pannel.Cursor = Cursors.Hand;
            wallpaper_pannel.Location = new Point(495, 258);
            wallpaper_pannel.Name = "wallpaper_pannel";
            wallpaper_pannel.Size = new Size(158, 148);
            wallpaper_pannel.TabIndex = 7;
            wallpaper_pannel.Click += wallpaper_pannel_Click;
            // 
            // background_pannel
            // 
            background_pannel.BackgroundImage = (Image)resources.GetObject("background_pannel.BackgroundImage");
            background_pannel.BackgroundImageLayout = ImageLayout.None;
            background_pannel.Cursor = Cursors.Hand;
            background_pannel.Location = new Point(289, 258);
            background_pannel.Name = "background_pannel";
            background_pannel.Size = new Size(158, 148);
            background_pannel.TabIndex = 6;
            background_pannel.Click += background_pannel_Click;
            // 
            // startup_pannel
            // 
            startup_pannel.BackgroundImage = (Image)resources.GetObject("startup_pannel.BackgroundImage");
            startup_pannel.BackgroundImageLayout = ImageLayout.None;
            startup_pannel.Cursor = Cursors.Hand;
            startup_pannel.Location = new Point(86, 258);
            startup_pannel.Name = "startup_pannel";
            startup_pannel.Size = new Size(158, 148);
            startup_pannel.TabIndex = 5;
            startup_pannel.Click += startup_pannel_Click;
            // 
            // Optmize
            // 
            Optmize.AutoSize = true;
            Optmize.BackColor = Color.FromArgb(161, 209, 229);
            Optmize.BackgroundImageLayout = ImageLayout.None;
            Optmize.Cursor = Cursors.Hand;
            Optmize.FlatAppearance.BorderSize = 0;
            Optmize.FlatStyle = FlatStyle.Flat;
            Optmize.Font = new Font("Microsoft Sans Serif", 11.25F);
            Optmize.ImageAlign = ContentAlignment.MiddleLeft;
            Optmize.Location = new Point(234, 432);
            Optmize.Name = "Optmize";
            Optmize.Size = new Size(132, 39);
            Optmize.TabIndex = 8;
            Optmize.Text = "Optimize";
            Optmize.UseVisualStyleBackColor = false;
            Optmize.Click += Optmize_Click;
            // 
            // button1
            // 
            button1.BackColor = Color.FromArgb(161, 209, 229);
            button1.BackgroundImageLayout = ImageLayout.None;
            button1.Cursor = Cursors.Hand;
            button1.FlatAppearance.BorderSize = 0;
            button1.FlatStyle = FlatStyle.Flat;
            button1.Font = new Font("Microsoft Sans Serif", 11.25F);
            button1.Location = new Point(372, 432);
            button1.Name = "button1";
            button1.Size = new Size(132, 39);
            button1.TabIndex = 9;
            button1.Text = "Reset";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Microsoft Sans Serif", 12F);
            label1.Location = new Point(147, 61);
            label1.Name = "label1";
            label1.Size = new Size(416, 20);
            label1.TabIndex = 3;
            label1.Text = "Choose the Settings That Will Best Optimize Your System";
            // 
            // Main
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.Control;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.None;
            ClientSize = new Size(723, 483);
            Controls.Add(button1);
            Controls.Add(Optmize);
            Controls.Add(wallpaper_pannel);
            Controls.Add(internet_pannel);
            Controls.Add(background_pannel);
            Controls.Add(startup_pannel);
            Controls.Add(roblox_pannel);
            Controls.Add(label1);
            Controls.Add(graphic_pannel);
            Controls.Add(border);
            Controls.Add(pictureBox1);
            FormBorderStyle = FormBorderStyle.None;
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "Main";
            Text = "Roblox Ping Optimizer";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            border.ResumeLayout(false);
            border.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)setting_btn).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)close_btn).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private PictureBox pictureBox1;
        private Panel border;
        private PictureBox close_btn;
        private Panel graphic_pannel;
        private Panel roblox_pannel;
        private Panel internet_pannel;
        private PictureBox setting_btn;
        private PictureBox pictureBox3;
        private Panel wallpaper_pannel;
        private Panel background_pannel;
        private Panel startup_pannel;
        private Button Optmize;
        private Button button1;
        private Label label1;
    }
}
