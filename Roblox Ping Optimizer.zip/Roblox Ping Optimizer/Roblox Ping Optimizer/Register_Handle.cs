﻿using System.Text;
using System.Security.Cryptography;

namespace Roblox_Ping_Optimizer
{
    internal class Register_Handle
    {
        private const string valid = "17-53-5D-37-3F-2D-F3-FB-36-78-9C-71-77-F6-62-A2-F0-0D-34-6C-5D-F1-E4-EF-06-AF-29-CF-88-AB-14-42";

        public bool register_user(string input_key)
        {
            using (SHA256 sha256 = SHA256.Create())
            {
                string input = input_key;

                byte[] hashBytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(input));

                string key = BitConverter.ToString(hashBytes);

                if (key != valid)
                {
                    MessageBox.Show("failed to register", "Registered", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return false;
                }
                else
                {
                    MessageBox.Show("you have sussfully registerd", "Registered", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return true;
                }
            }
        }



    }
}
