﻿using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace Roblox_Ping_Optimizer
{
    public partial class Setting : Form
    {
        public Setting()
        {
            InitializeComponent();
        }
        [DllImport("user32.DLL", EntryPoint = "ReleaseCapture")]
        private extern static void ReleaseCapture();
        [DllImport("user32.DLL", EntryPoint = "SendMessage")]
        private extern static void SendMessage(System.IntPtr one, int two, int three, int four);

        private void border_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(Handle, 0x112, 0xf012, 0);

        }

        private void save_btn_Click(object sender, System.EventArgs e)
        {
            DialogResult user_ask = MessageBox.Show(
            "Do you want to save your settings?",
            "Proceed",
            MessageBoxButtons.YesNo,
            MessageBoxIcon.Question
            );

            setting_handle handle = new setting_handle();

            if (user_ask == DialogResult.Yes)

            {
                handle.save_setting("default_roblox", default_roblox.Checked);
                handle.save_setting("high_roblox", high_roblox.Checked);
                handle.save_setting("ultra_roblox", ultra_roblox.Checked);

                handle.save_setting("disable_background", disable_bakcground.Checked);
                handle.save_setting("enable_background", enable_background.Checked);
                handle.save_setting("default_background", default_background.Checked);

                handle.save_setting("enable_wallpaper", enable_wallpaper.Checked);
                handle.save_setting("disable_wallpaper", disable_wallpaper.Checked);
                handle.save_setting("default_wallpaper", default_wallpaper.Checked);

                handle.save_setting("ultra_graphic", ultra_graphic.Checked);
                handle.save_setting("high_graphic", auto_graphic.Checked);
                handle.save_setting("default_graphic", default_graphic.Checked);

                handle.save_setting("enable_startup", startup_enable.Checked);
                handle.save_setting("disable_startup", startup_disable.Checked);
                handle.save_setting("default_startup", startup_default.Checked);
            }
        }

        private void Setting_Load(object sender, System.EventArgs e)
        {
            setting_handle api = new setting_handle();

            high_roblox.Checked = api.load_setting("high_roblox");
            default_roblox.Checked = api.load_setting("default_roblox");
            ultra_roblox.Checked = api.load_setting("ultra_roblox");

            enable_background.Checked = api.load_setting("enable_background");
            default_background.Checked = api.load_setting("default_background");
            disable_bakcground.Checked = api.load_setting("disable_background");

            auto_graphic.Checked = api.load_setting("high_graphic");
            default_graphic.Checked = api.load_setting("default_graphic");
            ultra_graphic.Checked = api.load_setting("ultra_graphic");

            enable_wallpaper.Checked = api.load_setting("enable_wallpaper");
            default_wallpaper.Checked = api.load_setting("default_wallpaper");
            disable_wallpaper.Checked = api.load_setting("disable_wallpaper");

            startup_enable.Checked = api.load_setting("enable_startup");
            startup_default.Checked = api.load_setting("default_startup");
            startup_disable.Checked = api.load_setting("disable_startup");

        }
    }
}
