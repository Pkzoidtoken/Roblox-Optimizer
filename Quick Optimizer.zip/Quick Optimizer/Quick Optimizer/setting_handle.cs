﻿using Microsoft.Win32;
using System;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace Roblox_Ping_Optimizer
{
    internal class setting_handle
    {

        [DllImport("user32.dll", CharSet = CharSet.Auto)]
        private static extern int SystemParametersInfo(int uAction, int uParam, string lpvParam, int fuWinIni);

        private const int SPI_SETDESKWALLPAPER = 0x0014;
        private const int SPIF_UPDATEINIFILE = 0x01;
        private const int SPIF_SENDCHANGE = 0x02;

        public void reset_setting()
        {
            default_graphic();
            enable_wallpaper();
            background__app_enable();
        }

        private void roblox_ultra(string path)
        {
            using (RegistryKey key = Registry.CurrentUser.OpenSubKey(@"SOFTWARE\Microsoft\Windows NT\CurrentVersion\AppCompatFlags\Layers", writable: true))
            {
                if (key != null)
                {
                    key.SetValue(path, "DISABLETHEMES 16BITCOLOR HIGHDPIAWARE DISABLEUSERCALLBACKEXCEPTION DISABLEDWM DISABLEDXMAXIMIZEDWINDOWEDMODE DISABLENX GLOBALMEMORYSTATUSLIE EMULATEHEAP HEAPDECOMMITONFREE", RegistryValueKind.String);
                    key.Close();
                }
            }
        }

        private void roblox_high(string path)
        {
            using (RegistryKey key = Registry.CurrentUser.OpenSubKey(@"SOFTWARE\Microsoft\Windows NT\CurrentVersion\AppCompatFlags\Layers", writable: true))
            {
                if (key != null)
                {
                    key.SetValue(path, "DISABLETHEMES HIGHDPIAWARE DISABLEUSERCALLBACKEXCEPTION", RegistryValueKind.String);
                    key.Close();
                }
            }
        }

        private void roblox_default(string path)
        {
            using (RegistryKey key = Registry.CurrentUser.OpenSubKey(@"SOFTWARE\Microsoft\Windows NT\CurrentVersion\AppCompatFlags\Layers", writable: true))
            {
                if (key != null)
                {
                    key.SetValue(path, "Default", RegistryValueKind.String);
                    key.Close();
                }
            }
        }

        private void ultra_graphic()
        {
            using (RegistryKey key = Registry.CurrentUser.OpenSubKey(@"SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\VisualEffects", writable: true))
            {
                if (key != null)
                {
                    string value_reg = key.GetValue("VisualFXSetting", "0").ToString() ?? "0";

                    if (value_reg == "2")
                    {
                        MessageBox.Show(
                        "Ultra graphic settings Already applied",
                        "Graphic",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Warning
                    );

                    }

                    else
                    {
                        key.SetValue("VisualFXSetting", 2, RegistryValueKind.DWord);
                        key.Close();
                        MessageBox.Show(
                            "The Ultra graphic settings have been successfully applied to the system",
                            "Graphic Configuration Update",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Information
                        );
                    }

                }
            }
        }

        private void window_choice()
        {
            using (RegistryKey key = Registry.CurrentUser.OpenSubKey(@"SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\VisualEffects", writable: true))
            {
                if (key != null)
                {

                    string value_reg = key.GetValue("VisualFXSetting", "2").ToString() ?? "2";

                    if (value_reg == "0")
                    {
                        MessageBox.Show(
                        "Window Choice graphic settings Already applied",
                        "Graphic",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Warning
                    );
                    }

                    else
                    {
                        key.SetValue("VisualFXSetting", 0, RegistryValueKind.DWord);
                        key.Close();
                        MessageBox.Show("Window Choice graphics updated.",
                            "Update",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Information);
                    }

                }
            }
        }

        private void default_graphic()
        {
            using (RegistryKey key = Registry.CurrentUser.OpenSubKey(@"SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\VisualEffects", writable: true))
            {
                if (key != null)
                {

                    string value_reg = key.GetValue("VisualFXSetting", "0").ToString() ?? "0";

                    if (value_reg == "1")
                    {
                        MessageBox.Show(
                        "default graphic settings Already applied",
                        "Graphic",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);
                    }

                    else
                    {
                        key.SetValue("VisualFXSetting", 1, RegistryValueKind.DWord);
                        key.Close();
                        MessageBox.Show(
                            "The default graphic settings have been successfully applied to the system. You can now proceed with your operations without any issues.",
                            "Graphic Configuration Update",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Information);
                    }
                }
            }
        }

        public void internet_hanlde()
        {
            internet_optimizer.Class1 call = new internet_optimizer.Class1();

            call.Optimized_Internet();
            call.clean_cache();
            MessageBox.Show(
                "The internet settings have been successfully optimized to enhance performance. You can now enjoy faster and more reliable connectivity.",
                "Internet Optimization Complete",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information
            );
        }

        public void roblox_handle()
        {
            using (OpenFileDialog file = new OpenFileDialog())
            {
                file.Title = "Select Roblox App";
                if (file.ShowDialog() == DialogResult.OK)
                {
                    if (load_setting("ultra_roblox"))
                    {
                        roblox_ultra(path: file.FileName);
                    }
                    else if (load_setting("high_roblox"))
                    {
                        roblox_high(path: file.FileName);
                    }
                    else if (load_setting("default_roblox"))
                    {
                        roblox_default(path: file.FileName);
                    }
                }
            }

        }

        public void graphic_handle()
        {
            if (load_setting("ultra_graphic"))
            {
                ultra_graphic();
            }
            else if (load_setting("high_graphic"))
            {
                window_choice();
            }
            else if (load_setting("default_graphic"))
            {
                default_graphic();
            }
        }

        public void startup_clean()
        {
            using (RegistryKey key = Registry.CurrentUser.OpenSubKey(@"SOFTWARE\Microsoft\Windows\CurrentVersion\Run", writable: true))

            {
                if (key != null)
                {
                    foreach (string subKeyName in key.GetValueNames())
                    {
                        key.DeleteValue(subKeyName);
                    }
                    MessageBox.Show(
                    "All startup programs have been successfully disabled. This change will help improve system boot time and overall performance.",
                    "Startup Programs Disabled",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information
                    );

                }
            }
        }

        private void enable_wallpaper()
        {
            using (RegistryKey key = Registry.CurrentUser.OpenSubKey(@"Control Panel\Desktop", true))
            {
                if (key != null)
                {
                    key.SetValue("WallPaper", key.GetValue("backup") ?? "Wallpaper");
                    key.Close();
                }
                SystemParametersInfo(SPI_SETDESKWALLPAPER, 0, null, SPIF_UPDATEINIFILE | SPIF_SENDCHANGE);
                MessageBox.Show(
                    "Default wallpaper settings have been successfully restored.",
                    "Wallpaper Restored",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information
                );
            }
        }

        private void disable_wallpaper()
        {
            using (RegistryKey key = Registry.CurrentUser.OpenSubKey(@"Control Panel\Desktop", true))
            {
                if (key != null)
                {
                    key.SetValue("backup", key.GetValue("WallPaper") ?? "Wallpaper");
                    key.SetValue("WallPaper", "");
                    key.Close();
                }

                SystemParametersInfo(SPI_SETDESKWALLPAPER, 0, null, SPIF_UPDATEINIFILE | SPIF_SENDCHANGE);
                MessageBox.Show(
                "Wallpaper has been successfully disabled.",
                "Wallpaper Disabled",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information
                );
            }
        }

        private void background__app_enable()
        {
            using (RegistryKey key = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Policies\Microsoft\Windows\AppPrivacy", writable: true))
            {
                if (key != null)
                {
                    string value_reg = key.GetValue("LetAppsRunInBackground", "1").ToString() ?? "1";

                    if (value_reg == "0")
                    {
                        MessageBox.Show(
                        "Background Apps Already Enabled",
                        "Background",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);
                    }

                    else
                    {
                        key.SetValue("LetAppsRunInBackground", 0, RegistryValueKind.DWord);
                        key.Close();
                        MessageBox.Show(
                        "Background apps have been successfully enabled.",
                        "Background Apps Enabled",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Information);
                    }
                }

                else
                {
                    RegistryKey New = Registry.CurrentUser.CreateSubKey(@"SOFTWARE\Policies\Microsoft\Windows\AppPrivacy", true);
                    New.SetValue("LetAppsRunInBackground", 0, RegistryValueKind.DWord);
                    New.Close();
                }
            }

        }

        private void background__app_disable()
        {
            using (RegistryKey key = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Policies\Microsoft\Windows\AppPrivacy", writable: true))
            {
                if (key != null)
                {
                    string value_reg = key.GetValue("LetAppsRunInBackground", "0").ToString() ?? "0";

                    if (value_reg == "2")
                    {
                        MessageBox.Show(
                        "Background Apps Already Disabled",
                        "Background",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);
                    }

                    else
                    {
                        key.SetValue("LetAppsRunInBackground", 2, RegistryValueKind.DWord);
                        key.Close();
                        MessageBox.Show(
                        "Background apps have been successfully disabled.",
                        "Background Apps Disabled",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Information);
                    }
                }

                else
                {
                    RegistryKey New = Registry.LocalMachine.CreateSubKey(@"SOFTWARE\Policies\Microsoft\Windows\AppPrivacy", writable: true);
                    New.SetValue("LetAppsRunInBackground", 2, RegistryValueKind.DWord);
                    New.Close();
                }
            }
        }

        public void wallpaper_handle()
        {
            if (load_setting("disable_wallpaper"))
            {
                disable_wallpaper();
            }
            else if (load_setting("enable_wallpaper"))
            {
                enable_wallpaper();
            }
            else
            {
                disable_wallpaper();
            }
        }

        public void background_handle()
        {
            if (load_setting("disable_background"))
            {
                background__app_disable();
            }
            else if (load_setting("enable_background"))
            {
                background__app_enable();
            }
            else
            {
                background__app_disable();
            }
        }

        public void save_setting(string name, object value)
        {
            using (RegistryKey reg_key = Registry.CurrentUser.OpenSubKey(@"SOFTWARE\roblox_ping_optimizer", writable: true))
            {
                if (reg_key != null)
                {
                    reg_key.SetValue(name, value, RegistryValueKind.String);
                    reg_key.Close();
                }
                else
                {
                    RegistryKey key = Registry.CurrentUser.CreateSubKey(@"SOFTWARE\roblox_ping_optimizer", writable: true);
                    key.SetValue(name, value, RegistryValueKind.String);
                    key.Close();
                }
            }
        }

        public bool load_setting(string name)
        {
            using (RegistryKey   load_key = Registry.CurrentUser.OpenSubKey(@"SOFTWARE\roblox_ping_optimizer", writable: true))
            {
                if (load_key != null)
                {
                    var reg_read = load_key.GetValue(name);

                    return Convert.ToBoolean(reg_read);
                }
                else
                {
                    return true;
                }
            }
        }
    }
}
