﻿using System;
using System.IO;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace Roblox_Ping_Optimizer
{
    public partial class Optimizer : Form
    {
        public Optimizer()
        {
            InitializeComponent();
        }

        [DllImport("user32.DLL", EntryPoint = "ReleaseCapture")]
        private extern static void ReleaseCapture();
        [DllImport("user32.DLL", EntryPoint = "SendMessage")]
        private extern static void SendMessage(System.IntPtr one, int two, int three, int four);


        private void pictureBox1_Click(object sender, EventArgs e)
        {
            DialogResult user_ask = MessageBox.Show(
                "Do you want to close the application?",
                "Proceed",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);

            if (user_ask == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            Setting setting = new Setting();
            setting.ShowDialog();
        }

        private void border_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(Handle, 0x112, 0xf012, 0);
        }

        private void btn_optimize_Click(object sender, EventArgs e)
        {
            DialogResult user_ask = MessageBox.Show(
            "Do you want to optimize All Setting On the system?",
            "Optimize",
            MessageBoxButtons.YesNo,
            MessageBoxIcon.Question);

            if (user_ask == DialogResult.Yes)
            {
                setting_handle call = new setting_handle();

                call.graphic_handle();
                call.internet_hanlde();
                call.roblox_handle();
                call.wallpaper_handle();
                call.startup_clean();
                call.background_handle();
            }
        }

        private void Reset_Click(object sender, EventArgs e)
        {
            DialogResult user_ask = MessageBox.Show(
              "Do you want to reset all settings?",
              "Reset",
              MessageBoxButtons.YesNo,
              MessageBoxIcon.Question);

            if (user_ask == DialogResult.Yes)
            {
                setting_handle call = new setting_handle();
                call.reset_setting();
            }
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            try
            {
                string help_file = ".//Optimizer.chm";

                Help.ShowHelp(this, help_file);
            }

            catch (FileNotFoundException)
            {
                MessageBox.Show("The help file could not be found. Please ensure the file is in the correct location.",
                                "Help File Missing",
                                MessageBoxButtons.OK,
                MessageBoxIcon.Warning);
            }
        }

        private void graphic_check_Click(object sender, EventArgs e)
        {
            DialogResult user_warn = MessageBox.Show(
                "Do you want to apply the graphic settings?", "Procced",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Warning
                );

            if (user_warn == DialogResult.Yes)
            {
                setting_handle call = new setting_handle();
                call.graphic_handle();
            }
        }

        private void internet_check_Click(object sender, EventArgs e)
        {
            DialogResult user_warn = MessageBox.Show(
              "Do You Want Optmize Internet?",
              "Procced",
              MessageBoxButtons.YesNo,
              MessageBoxIcon.Warning
              );

            if (user_warn == DialogResult.Yes)
            {
                setting_handle call = new setting_handle();
                call.internet_hanlde();
            }
        }

        private void startup_check_Click(object sender, EventArgs e)
        {
            DialogResult user_warn = MessageBox.Show(
              "Do you want to apply settings on startup?", "Procced",
              MessageBoxButtons.YesNo,
              MessageBoxIcon.Warning
              );

            if (user_warn == DialogResult.Yes)
            {
                setting_handle call = new setting_handle();
                call.startup_clean();
            }
        }

        private void background_check_Click(object sender, EventArgs e)
        {
            DialogResult user_warn = MessageBox.Show(
               "Do you want to apply settings on background apps?",
               "Procced",
              MessageBoxButtons.YesNo,
              MessageBoxIcon.Warning
              );

            if (user_warn == DialogResult.Yes)
            {
                setting_handle call = new setting_handle();
                call.background_handle();
            }
        }

        private void wallpaper_check_Click(object sender, EventArgs e)
        {
            DialogResult user_warn = MessageBox.Show(
                "Do you want to apply settings on wallpaper?", "Procced",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Warning
                );

            if (user_warn == DialogResult.Yes)
            {
                setting_handle call = new setting_handle();
                call.wallpaper_handle();
            }
        }

        private void roblox_pannel_Click(object sender, EventArgs e)
        {
            DialogResult user_warn = MessageBox.Show(
             "Do You Want Optmize Roblox?",
             "Procced",
             MessageBoxButtons.YesNo,
             MessageBoxIcon.Warning
             );

            if (user_warn == DialogResult.Yes)
            {
                setting_handle call = new setting_handle();
                call.roblox_handle();
            }
        }
    }
}

