﻿namespace Roblox_Ping_Optimizer
{
    partial class Optimizer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Optimizer));
            this.border = new System.Windows.Forms.Panel();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.Select_All = new System.Windows.Forms.Label();
            this.graphic_check = new System.Windows.Forms.Panel();
            this.roblox_pannel = new System.Windows.Forms.Panel();
            this.internet_check = new System.Windows.Forms.Panel();
            this.wallpaper_check = new System.Windows.Forms.Panel();
            this.background_check = new System.Windows.Forms.Panel();
            this.startup_check = new System.Windows.Forms.Panel();
            this.btn_optimize = new System.Windows.Forms.Button();
            this.Reset = new System.Windows.Forms.Button();
            this.border.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // border
            // 
            this.border.BackColor = System.Drawing.Color.Transparent;
            this.border.Controls.Add(this.pictureBox3);
            this.border.Controls.Add(this.pictureBox2);
            this.border.Controls.Add(this.pictureBox1);
            this.border.Location = new System.Drawing.Point(1, 2);
            this.border.Name = "border";
            this.border.Size = new System.Drawing.Size(786, 40);
            this.border.TabIndex = 1;
            this.border.MouseDown += new System.Windows.Forms.MouseEventHandler(this.border_MouseDown);
            // 
            // pictureBox3
            // 
            this.pictureBox3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox3.Image = global::Roblox_Ping_Optimizer.Properties.Resources.setting;
            this.pictureBox3.Location = new System.Drawing.Point(680, 10);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(20, 20);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox3.TabIndex = 2;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox2.Image = global::Roblox_Ping_Optimizer.Properties.Resources.help;
            this.pictureBox2.Location = new System.Drawing.Point(716, 10);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(20, 20);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox2.TabIndex = 1;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox1.Image = global::Roblox_Ping_Optimizer.Properties.Resources.close;
            this.pictureBox1.Location = new System.Drawing.Point(753, 10);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(18, 22);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // Select_All
            // 
            this.Select_All.AutoSize = true;
            this.Select_All.BackColor = System.Drawing.Color.Transparent;
            this.Select_All.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Select_All.Location = new System.Drawing.Point(193, 60);
            this.Select_All.Name = "Select_All";
            this.Select_All.Size = new System.Drawing.Size(416, 20);
            this.Select_All.TabIndex = 9;
            this.Select_All.Text = "Choose the Settings That Will Best Optimize Your System";
            // 
            // graphic_check
            // 
            this.graphic_check.BackgroundImage = global::Roblox_Ping_Optimizer.Properties.Resources.pannel_graphic;
            this.graphic_check.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.graphic_check.Cursor = System.Windows.Forms.Cursors.Hand;
            this.graphic_check.Location = new System.Drawing.Point(103, 93);
            this.graphic_check.Name = "graphic_check";
            this.graphic_check.Size = new System.Drawing.Size(160, 173);
            this.graphic_check.TabIndex = 16;
            this.graphic_check.Click += new System.EventHandler(this.graphic_check_Click);
            // 
            // roblox_pannel
            // 
            this.roblox_pannel.BackgroundImage = global::Roblox_Ping_Optimizer.Properties.Resources.pannel_texture;
            this.roblox_pannel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.roblox_pannel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.roblox_pannel.Location = new System.Drawing.Point(309, 93);
            this.roblox_pannel.Name = "roblox_pannel";
            this.roblox_pannel.Size = new System.Drawing.Size(160, 173);
            this.roblox_pannel.TabIndex = 17;
            this.roblox_pannel.Click += new System.EventHandler(this.roblox_pannel_Click);
            // 
            // internet_check
            // 
            this.internet_check.BackgroundImage = global::Roblox_Ping_Optimizer.Properties.Resources.pannel_internet;
            this.internet_check.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.internet_check.Cursor = System.Windows.Forms.Cursors.Hand;
            this.internet_check.Location = new System.Drawing.Point(516, 93);
            this.internet_check.Name = "internet_check";
            this.internet_check.Size = new System.Drawing.Size(160, 173);
            this.internet_check.TabIndex = 18;
            this.internet_check.Click += new System.EventHandler(this.internet_check_Click);
            // 
            // wallpaper_check
            // 
            this.wallpaper_check.BackgroundImage = global::Roblox_Ping_Optimizer.Properties.Resources.pannel_wallpaper;
            this.wallpaper_check.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.wallpaper_check.Cursor = System.Windows.Forms.Cursors.Hand;
            this.wallpaper_check.Location = new System.Drawing.Point(516, 284);
            this.wallpaper_check.Name = "wallpaper_check";
            this.wallpaper_check.Size = new System.Drawing.Size(160, 173);
            this.wallpaper_check.TabIndex = 19;
            this.wallpaper_check.Click += new System.EventHandler(this.wallpaper_check_Click);
            // 
            // background_check
            // 
            this.background_check.BackgroundImage = global::Roblox_Ping_Optimizer.Properties.Resources.panneL_background;
            this.background_check.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.background_check.Cursor = System.Windows.Forms.Cursors.Hand;
            this.background_check.Location = new System.Drawing.Point(309, 284);
            this.background_check.Name = "background_check";
            this.background_check.Size = new System.Drawing.Size(160, 173);
            this.background_check.TabIndex = 18;
            this.background_check.Click += new System.EventHandler(this.background_check_Click);
            // 
            // startup_check
            // 
            this.startup_check.BackgroundImage = global::Roblox_Ping_Optimizer.Properties.Resources.pannel_pc_startup;
            this.startup_check.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.startup_check.Cursor = System.Windows.Forms.Cursors.Hand;
            this.startup_check.Location = new System.Drawing.Point(103, 284);
            this.startup_check.Name = "startup_check";
            this.startup_check.Size = new System.Drawing.Size(160, 173);
            this.startup_check.TabIndex = 17;
            this.startup_check.Click += new System.EventHandler(this.startup_check_Click);
            // 
            // btn_optimize
            // 
            this.btn_optimize.AutoSize = true;
            this.btn_optimize.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(209)))), ((int)(((byte)(229)))));
            this.btn_optimize.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btn_optimize.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_optimize.FlatAppearance.BorderSize = 0;
            this.btn_optimize.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_optimize.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_optimize.Location = new System.Drawing.Point(257, 480);
            this.btn_optimize.Name = "btn_optimize";
            this.btn_optimize.Size = new System.Drawing.Size(132, 39);
            this.btn_optimize.TabIndex = 20;
            this.btn_optimize.Text = "Optimize";
            this.btn_optimize.UseVisualStyleBackColor = false;
            this.btn_optimize.Click += new System.EventHandler(this.btn_optimize_Click);
            // 
            // Reset
            // 
            this.Reset.AutoSize = true;
            this.Reset.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(209)))), ((int)(((byte)(229)))));
            this.Reset.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.Reset.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Reset.FlatAppearance.BorderSize = 0;
            this.Reset.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Reset.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Reset.Location = new System.Drawing.Point(395, 480);
            this.Reset.Name = "Reset";
            this.Reset.Size = new System.Drawing.Size(132, 39);
            this.Reset.TabIndex = 22;
            this.Reset.Text = "Reset";
            this.Reset.UseVisualStyleBackColor = false;
            this.Reset.Click += new System.EventHandler(this.Reset_Click);
            // 
            // Optimizer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Roblox_Ping_Optimizer.Properties.Resources.UI;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.ClientSize = new System.Drawing.Size(784, 544);
            this.Controls.Add(this.Reset);
            this.Controls.Add(this.btn_optimize);
            this.Controls.Add(this.startup_check);
            this.Controls.Add(this.background_check);
            this.Controls.Add(this.wallpaper_check);
            this.Controls.Add(this.internet_check);
            this.Controls.Add(this.roblox_pannel);
            this.Controls.Add(this.graphic_check);
            this.Controls.Add(this.Select_All);
            this.Controls.Add(this.border);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Optimizer";
            this.Text = "Optimizer";
            this.border.ResumeLayout(false);
            this.border.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel border;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label Select_All;
        private System.Windows.Forms.Panel graphic_check;
        private System.Windows.Forms.Panel roblox_pannel;
        private System.Windows.Forms.Panel internet_check;
        private System.Windows.Forms.Panel wallpaper_check;
        private System.Windows.Forms.Panel background_check;
        private System.Windows.Forms.Panel startup_check;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button btn_optimize;
        private System.Windows.Forms.Button Reset;
    }
}