﻿namespace Roblox_Ping_Optimizer
{
    partial class Setting
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Setting));
            this.save_btn = new System.Windows.Forms.Button();
            this.panel5 = new System.Windows.Forms.Panel();
            this.startup_enable = new System.Windows.Forms.RadioButton();
            this.startup_default = new System.Windows.Forms.RadioButton();
            this.startup_disable = new System.Windows.Forms.RadioButton();
            this.panel4 = new System.Windows.Forms.Panel();
            this.default_wallpaper = new System.Windows.Forms.RadioButton();
            this.disable_wallpaper = new System.Windows.Forms.RadioButton();
            this.enable_wallpaper = new System.Windows.Forms.RadioButton();
            this.panel3 = new System.Windows.Forms.Panel();
            this.default_graphic = new System.Windows.Forms.RadioButton();
            this.auto_graphic = new System.Windows.Forms.RadioButton();
            this.ultra_graphic = new System.Windows.Forms.RadioButton();
            this.panel2 = new System.Windows.Forms.Panel();
            this.default_background = new System.Windows.Forms.RadioButton();
            this.enable_background = new System.Windows.Forms.RadioButton();
            this.disable_bakcground = new System.Windows.Forms.RadioButton();
            this.panel1 = new System.Windows.Forms.Panel();
            this.default_roblox = new System.Windows.Forms.RadioButton();
            this.high_roblox = new System.Windows.Forms.RadioButton();
            this.ultra_roblox = new System.Windows.Forms.RadioButton();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel5.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // save_btn
            // 
            this.save_btn.AutoSize = true;
            this.save_btn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(209)))), ((int)(((byte)(229)))));
            this.save_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.save_btn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.save_btn.FlatAppearance.BorderSize = 0;
            this.save_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.save_btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.save_btn.Location = new System.Drawing.Point(96, 318);
            this.save_btn.Name = "save_btn";
            this.save_btn.Size = new System.Drawing.Size(132, 39);
            this.save_btn.TabIndex = 36;
            this.save_btn.Text = "Save";
            this.save_btn.UseVisualStyleBackColor = false;
            this.save_btn.Click += new System.EventHandler(this.save_btn_Click);
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.Transparent;
            this.panel5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.panel5.Controls.Add(this.startup_enable);
            this.panel5.Controls.Add(this.startup_default);
            this.panel5.Controls.Add(this.startup_disable);
            this.panel5.Location = new System.Drawing.Point(16, 280);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(318, 24);
            this.panel5.TabIndex = 46;
            // 
            // startup_enable
            // 
            this.startup_enable.AutoSize = true;
            this.startup_enable.Location = new System.Drawing.Point(113, 4);
            this.startup_enable.Name = "startup_enable";
            this.startup_enable.Size = new System.Drawing.Size(72, 17);
            this.startup_enable.TabIndex = 28;
            this.startup_enable.TabStop = true;
            this.startup_enable.Text = "Enable All";
            this.startup_enable.UseVisualStyleBackColor = true;
            // 
            // startup_default
            // 
            this.startup_default.AutoSize = true;
            this.startup_default.Location = new System.Drawing.Point(223, 3);
            this.startup_default.Name = "startup_default";
            this.startup_default.Size = new System.Drawing.Size(95, 17);
            this.startup_default.TabIndex = 27;
            this.startup_default.TabStop = true;
            this.startup_default.Text = "Default Setting";
            this.startup_default.UseVisualStyleBackColor = true;
            // 
            // startup_disable
            // 
            this.startup_disable.AutoSize = true;
            this.startup_disable.Location = new System.Drawing.Point(3, 4);
            this.startup_disable.Name = "startup_disable";
            this.startup_disable.Size = new System.Drawing.Size(74, 17);
            this.startup_disable.TabIndex = 26;
            this.startup_disable.TabStop = true;
            this.startup_disable.Text = "Disable All";
            this.startup_disable.UseVisualStyleBackColor = true;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.Transparent;
            this.panel4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.panel4.Controls.Add(this.default_wallpaper);
            this.panel4.Controls.Add(this.disable_wallpaper);
            this.panel4.Controls.Add(this.enable_wallpaper);
            this.panel4.Location = new System.Drawing.Point(16, 216);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(318, 24);
            this.panel4.TabIndex = 45;
            // 
            // default_wallpaper
            // 
            this.default_wallpaper.AutoSize = true;
            this.default_wallpaper.Location = new System.Drawing.Point(223, 3);
            this.default_wallpaper.Name = "default_wallpaper";
            this.default_wallpaper.Size = new System.Drawing.Size(95, 17);
            this.default_wallpaper.TabIndex = 27;
            this.default_wallpaper.TabStop = true;
            this.default_wallpaper.Text = "Default Setting";
            this.default_wallpaper.UseVisualStyleBackColor = true;
            // 
            // disable_wallpaper
            // 
            this.disable_wallpaper.AutoSize = true;
            this.disable_wallpaper.Location = new System.Drawing.Point(3, 4);
            this.disable_wallpaper.Name = "disable_wallpaper";
            this.disable_wallpaper.Size = new System.Drawing.Size(60, 17);
            this.disable_wallpaper.TabIndex = 26;
            this.disable_wallpaper.TabStop = true;
            this.disable_wallpaper.Text = "Disable";
            this.disable_wallpaper.UseVisualStyleBackColor = true;
            // 
            // enable_wallpaper
            // 
            this.enable_wallpaper.AutoSize = true;
            this.enable_wallpaper.Location = new System.Drawing.Point(113, 4);
            this.enable_wallpaper.Name = "enable_wallpaper";
            this.enable_wallpaper.Size = new System.Drawing.Size(58, 17);
            this.enable_wallpaper.TabIndex = 25;
            this.enable_wallpaper.TabStop = true;
            this.enable_wallpaper.Text = "Enable";
            this.enable_wallpaper.UseVisualStyleBackColor = true;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Transparent;
            this.panel3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.panel3.Controls.Add(this.default_graphic);
            this.panel3.Controls.Add(this.auto_graphic);
            this.panel3.Controls.Add(this.ultra_graphic);
            this.panel3.Location = new System.Drawing.Point(16, 152);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(318, 24);
            this.panel3.TabIndex = 44;
            // 
            // default_graphic
            // 
            this.default_graphic.AutoSize = true;
            this.default_graphic.Location = new System.Drawing.Point(223, 3);
            this.default_graphic.Name = "default_graphic";
            this.default_graphic.Size = new System.Drawing.Size(95, 17);
            this.default_graphic.TabIndex = 27;
            this.default_graphic.TabStop = true;
            this.default_graphic.Text = "Default Setting";
            this.default_graphic.UseVisualStyleBackColor = true;
            // 
            // auto_graphic
            // 
            this.auto_graphic.AutoSize = true;
            this.auto_graphic.Location = new System.Drawing.Point(113, 3);
            this.auto_graphic.Name = "auto_graphic";
            this.auto_graphic.Size = new System.Drawing.Size(82, 17);
            this.auto_graphic.TabIndex = 26;
            this.auto_graphic.TabStop = true;
            this.auto_graphic.Text = "Auto Detect";
            this.auto_graphic.UseVisualStyleBackColor = true;
            // 
            // ultra_graphic
            // 
            this.ultra_graphic.AutoSize = true;
            this.ultra_graphic.Location = new System.Drawing.Point(3, 3);
            this.ultra_graphic.Name = "ultra_graphic";
            this.ultra_graphic.Size = new System.Drawing.Size(90, 17);
            this.ultra_graphic.TabIndex = 25;
            this.ultra_graphic.TabStop = true;
            this.ultra_graphic.Text = "Ultra Optimize";
            this.ultra_graphic.UseVisualStyleBackColor = true;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Transparent;
            this.panel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.panel2.Controls.Add(this.default_background);
            this.panel2.Controls.Add(this.enable_background);
            this.panel2.Controls.Add(this.disable_bakcground);
            this.panel2.Location = new System.Drawing.Point(16, 91);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(318, 24);
            this.panel2.TabIndex = 43;
            // 
            // default_background
            // 
            this.default_background.AutoSize = true;
            this.default_background.Location = new System.Drawing.Point(223, 3);
            this.default_background.Name = "default_background";
            this.default_background.Size = new System.Drawing.Size(95, 17);
            this.default_background.TabIndex = 27;
            this.default_background.TabStop = true;
            this.default_background.Text = "Default Setting";
            this.default_background.UseVisualStyleBackColor = true;
            // 
            // enable_background
            // 
            this.enable_background.AutoSize = true;
            this.enable_background.Location = new System.Drawing.Point(113, 3);
            this.enable_background.Name = "enable_background";
            this.enable_background.Size = new System.Drawing.Size(72, 17);
            this.enable_background.TabIndex = 26;
            this.enable_background.TabStop = true;
            this.enable_background.Text = "Enable All";
            this.enable_background.UseVisualStyleBackColor = true;
            // 
            // disable_bakcground
            // 
            this.disable_bakcground.AutoSize = true;
            this.disable_bakcground.Location = new System.Drawing.Point(3, 3);
            this.disable_bakcground.Name = "disable_bakcground";
            this.disable_bakcground.Size = new System.Drawing.Size(74, 17);
            this.disable_bakcground.TabIndex = 25;
            this.disable_bakcground.TabStop = true;
            this.disable_bakcground.Text = "Disable All";
            this.disable_bakcground.UseVisualStyleBackColor = true;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Transparent;
            this.panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.panel1.Controls.Add(this.default_roblox);
            this.panel1.Controls.Add(this.high_roblox);
            this.panel1.Controls.Add(this.ultra_roblox);
            this.panel1.Location = new System.Drawing.Point(16, 32);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(318, 24);
            this.panel1.TabIndex = 42;
            // 
            // default_roblox
            // 
            this.default_roblox.AutoSize = true;
            this.default_roblox.Location = new System.Drawing.Point(223, 3);
            this.default_roblox.Name = "default_roblox";
            this.default_roblox.Size = new System.Drawing.Size(95, 17);
            this.default_roblox.TabIndex = 27;
            this.default_roblox.TabStop = true;
            this.default_roblox.Text = "Default Setting";
            this.default_roblox.UseVisualStyleBackColor = true;
            // 
            // high_roblox
            // 
            this.high_roblox.AutoSize = true;
            this.high_roblox.Location = new System.Drawing.Point(113, 4);
            this.high_roblox.Name = "high_roblox";
            this.high_roblox.Size = new System.Drawing.Size(83, 17);
            this.high_roblox.TabIndex = 26;
            this.high_roblox.TabStop = true;
            this.high_roblox.Text = "High Roblox";
            this.high_roblox.UseVisualStyleBackColor = true;
            // 
            // ultra_roblox
            // 
            this.ultra_roblox.AutoSize = true;
            this.ultra_roblox.Location = new System.Drawing.Point(3, 4);
            this.ultra_roblox.Name = "ultra_roblox";
            this.ultra_roblox.Size = new System.Drawing.Size(83, 17);
            this.ultra_roblox.TabIndex = 25;
            this.ultra_roblox.TabStop = true;
            this.ultra_roblox.Text = "Ultra Roblox";
            this.ultra_roblox.UseVisualStyleBackColor = true;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(12, 257);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(103, 20);
            this.label7.TabIndex = 41;
            this.label7.Text = "Startup Apps";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(12, 193);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(144, 20);
            this.label6.TabIndex = 40;
            this.label6.Text = "Desktop Wallpaper";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(12, 129);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(131, 20);
            this.label5.TabIndex = 39;
            this.label5.Text = "Graphic Optimize";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(12, 68);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(136, 20);
            this.label4.TabIndex = 38;
            this.label4.Text = "Background Apps";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(113, 20);
            this.label1.TabIndex = 37;
            this.label1.Text = "Roblox Setting";
            // 
            // Setting
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.ClientSize = new System.Drawing.Size(351, 369);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.save_btn);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "Setting";
            this.Text = "Setting";
            this.Load += new System.EventHandler(this.Setting_Load);
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button save_btn;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.RadioButton startup_enable;
        private System.Windows.Forms.RadioButton startup_default;
        private System.Windows.Forms.RadioButton startup_disable;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.RadioButton default_wallpaper;
        private System.Windows.Forms.RadioButton disable_wallpaper;
        private System.Windows.Forms.RadioButton enable_wallpaper;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.RadioButton default_graphic;
        private System.Windows.Forms.RadioButton auto_graphic;
        private System.Windows.Forms.RadioButton ultra_graphic;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.RadioButton default_background;
        private System.Windows.Forms.RadioButton enable_background;
        private System.Windows.Forms.RadioButton disable_bakcground;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.RadioButton default_roblox;
        private System.Windows.Forms.RadioButton high_roblox;
        private System.Windows.Forms.RadioButton ultra_roblox;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label1;
    }
}